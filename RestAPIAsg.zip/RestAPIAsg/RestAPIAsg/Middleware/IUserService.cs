﻿namespace RestAPIAsg.Middleware
{
    public interface IUserService
    {
        object GetById(object value);
    }
}