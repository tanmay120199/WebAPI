﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RestAPIAsg.Models
{
    public class AppSettings
    {
        public string Key { get; set; }
        //public char* Secret { get; set; }
        //public unsafe char* Value { get; set; }
    }
}
