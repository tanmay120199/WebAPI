using System;
using Xunit;

namespace TimeManagement
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
